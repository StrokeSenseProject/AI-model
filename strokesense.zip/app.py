
from pathlib import Path
from typing import Any, Dict, List, Literal, Optional
import json

import joblib
import numpy as np
import pandas as pd
import tensorflow as tf
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, ConfigDict, Field

DISCLAIMER = (
    "This prediction is for early screening support only and is not a medical diagnosis. "
    "Please consult a qualified healthcare professional for medical advice."
)

BASE_DIR = Path(__file__).resolve().parent
MODEL_PATH = BASE_DIR / "strokesense_model.keras"
SAVED_MODEL_DIR = BASE_DIR / "strokesense_saved_model"
THRESHOLD_PATH = BASE_DIR / "threshold.json"
FEATURE_SCHEMA_PATH = BASE_DIR / "feature_schema.json"
FEATURE_MAPPING_PATH = BASE_DIR / "feature_mapping.json"
MODEL_METADATA_PATH = BASE_DIR / "model_metadata.json"
PREPROCESSOR_PATH = BASE_DIR / "preprocessor.pkl"

app = FastAPI(title="StrokeSense Inference API", version="1.0.0")

model = None
model_load_mode = None
threshold = None
feature_columns = None
raw_feature_columns = None
feature_schema = None
feature_mapping = None
model_metadata = None
preprocessor = None
load_error = None

DEFAULT_FORBIDDEN_INPUT_COLUMNS = ["target", "stroke"]


class RawFeatures(BaseModel):
    model_config = ConfigDict(extra="forbid")

    age: float
    hypertension: int
    heart_disease: int
    ever_married: str
    work_type: str
    avg_glucose_level: float
    bmi: float
    smoking_status: str


class PredictionRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    mode: Literal["processed", "raw"] = Field(
        "processed",
        description="Use 'processed' for 18 numeric features or 'raw' for user-facing raw features."
    )
    features: Optional[List[float]] = Field(
        None,
        description="Exactly 18 numeric values ordered according to feature_mapping.json. Do not include target."
    )
    raw_features: Optional[RawFeatures] = Field(
        None,
        description="Raw user input. Requires preprocessor.pkl."
    )


class SavedModelWrapper:
    def __init__(self, saved_model_dir: Path):
        self.saved_model = tf.saved_model.load(str(saved_model_dir))

        if "serve" in self.saved_model.signatures:
            self.serving_fn = self.saved_model.signatures["serve"]
        elif "serving_default" in self.saved_model.signatures:
            self.serving_fn = self.saved_model.signatures["serving_default"]
        else:
            available = list(self.saved_model.signatures.keys())
            raise RuntimeError(f"No usable serving signature found in SavedModel. Available signatures: {available}")

    def predict(self, x, verbose=0):
        x = tf.convert_to_tensor(x, dtype=tf.float32)

        try:
            output = self.serving_fn(x)
        except TypeError:
            _, keyword_inputs = self.serving_fn.structured_input_signature
            if not keyword_inputs:
                raise
            input_key = list(keyword_inputs.keys())[0]
            output = self.serving_fn(**{input_key: x})

        if isinstance(output, dict):
            output_tensor = list(output.values())[0]
        else:
            output_tensor = output

        return output_tensor.numpy()


def load_model_with_fallback():
    keras_error_message = None

    if MODEL_PATH.exists():
        try:
            loaded_model = tf.keras.models.load_model(MODEL_PATH, compile=False)
            return loaded_model, "keras"
        except Exception as exc:
            keras_error_message = str(exc)

    if SAVED_MODEL_DIR.exists():
        loaded_model = SavedModelWrapper(SAVED_MODEL_DIR)
        return loaded_model, "saved_model"

    if keras_error_message is not None:
        raise RuntimeError(
            "Failed to load strokesense_model.keras and SavedModel fallback was not available. "
            f"Keras load error: {keras_error_message}"
        )

    raise FileNotFoundError(
        f"No model artifact found. Expected {MODEL_PATH} or {SAVED_MODEL_DIR}"
    )


def extract_feature_order_from_mapping(mapping_payload: Dict[str, Any], fallback_feature_cols: List[str]) -> List[str]:
    candidate_keys = [
        "processed_feature_columns",
        "model_feature_order",
        "feature_order",
        "output_feature_order",
        "feature_columns",
    ]
    for key in candidate_keys:
        value = mapping_payload.get(key)
        if isinstance(value, list) and len(value) > 0:
            return [str(item) for item in value]
    return [str(item) for item in fallback_feature_cols]


def forbidden_columns() -> List[str]:
    if isinstance(feature_schema, dict) and isinstance(feature_schema.get("forbidden_input_columns"), list):
        return [str(item) for item in feature_schema["forbidden_input_columns"]]
    if isinstance(feature_mapping, dict) and isinstance(feature_mapping.get("forbidden_input_columns"), list):
        return [str(item) for item in feature_mapping["forbidden_input_columns"]]
    return DEFAULT_FORBIDDEN_INPUT_COLUMNS


def assert_no_forbidden_keys(payload: Dict[str, Any], context: str) -> None:
    payload_keys_lower = {str(key).lower() for key in payload.keys()}
    forbidden_lower = {str(key).lower() for key in forbidden_columns()}
    found = sorted(payload_keys_lower.intersection(forbidden_lower))
    if found:
        raise HTTPException(
            status_code=400,
            detail=f"{context} must not include target/stroke columns: {found}"
        )


def load_artifacts():
    global model, model_load_mode, threshold, feature_columns, raw_feature_columns
    global feature_schema, feature_mapping, model_metadata, preprocessor

    if not THRESHOLD_PATH.exists():
        raise FileNotFoundError(f"Threshold file not found: {THRESHOLD_PATH}")
    if not FEATURE_SCHEMA_PATH.exists():
        raise FileNotFoundError(f"Feature schema file not found: {FEATURE_SCHEMA_PATH}")
    if not FEATURE_MAPPING_PATH.exists():
        raise FileNotFoundError(f"Feature mapping file not found: {FEATURE_MAPPING_PATH}")

    model, model_load_mode = load_model_with_fallback()

    with open(THRESHOLD_PATH, "r", encoding="utf-8") as f:
        threshold_payload = json.load(f)
    threshold = float(threshold_payload["threshold"])

    with open(FEATURE_SCHEMA_PATH, "r", encoding="utf-8") as f:
        feature_schema = json.load(f)

    with open(FEATURE_MAPPING_PATH, "r", encoding="utf-8") as f:
        feature_mapping = json.load(f)

    fallback_feature_cols = feature_schema.get("feature_columns", [])
    feature_columns = extract_feature_order_from_mapping(feature_mapping, fallback_feature_cols)
    raw_feature_columns = feature_mapping.get(
        "raw_feature_columns",
        feature_schema.get("raw_feature_columns", [])
    )
    raw_feature_columns = [str(item) for item in raw_feature_columns]

    expected_dim = int(feature_schema.get("input_dim", len(feature_columns)))
    if len(feature_columns) != expected_dim:
        raise ValueError(f"feature_mapping must define {expected_dim} processed features, got {len(feature_columns)}")

    forbidden_lower = {item.lower() for item in forbidden_columns()}
    if forbidden_lower.intersection({col.lower() for col in feature_columns}):
        raise ValueError("Processed feature order must not contain target/stroke.")
    if forbidden_lower.intersection({col.lower() for col in raw_feature_columns}):
        raise ValueError("Raw feature columns must not contain target/stroke.")

    if MODEL_METADATA_PATH.exists():
        with open(MODEL_METADATA_PATH, "r", encoding="utf-8") as f:
            model_metadata = json.load(f)
    else:
        model_metadata = {}

    if PREPROCESSOR_PATH.exists():
        preprocessor = joblib.load(PREPROCESSOR_PATH)
    else:
        preprocessor = None


try:
    load_artifacts()
except Exception as exc:
    model = None
    model_load_mode = None
    threshold = None
    feature_columns = None
    raw_feature_columns = None
    feature_schema = None
    feature_mapping = None
    model_metadata = None
    preprocessor = None
    load_error = str(exc)
else:
    load_error = None


@app.get("/health")
def health():
    return {
        "status": "ok" if model is not None else "error",
        "model_loaded": model is not None,
        "model_load_mode": model_load_mode,
        "processed_mode_enabled": model is not None,
        "raw_mode_enabled": model is not None and preprocessor is not None,
        "processed_feature_count": len(feature_columns) if feature_columns is not None else None,
        "raw_feature_columns": raw_feature_columns,
        "error": load_error,
    }


def predict_processed_array(arr: np.ndarray) -> Dict[str, Any]:
    if model is None or threshold is None or feature_columns is None:
        raise HTTPException(status_code=503, detail=f"Model artifacts are not loaded: {load_error}")

    arr = np.asarray(arr, dtype=np.float32).reshape(1, -1)
    expected_features = len(feature_columns)
    if arr.shape[1] != expected_features:
        raise HTTPException(
            status_code=400,
            detail=f"Expected {expected_features} processed numeric features, got {arr.shape[1]}. Do not include target."
        )

    if not np.all(np.isfinite(arr)):
        raise HTTPException(status_code=400, detail="All features must be finite numeric values.")

    stroke_probability = float(model.predict(arr, verbose=0).reshape(-1)[0])
    prediction = int(stroke_probability >= threshold)
    risk_label = "High Risk" if prediction == 1 else "Low Risk"

    return {
        "stroke_probability": stroke_probability,
        "threshold": threshold,
        "prediction": prediction,
        "risk_label": risk_label,
        "disclaimer": DISCLAIMER,
    }


def transform_raw_features(raw_features: RawFeatures) -> np.ndarray:
    if preprocessor is None:
        raise HTTPException(
            status_code=503,
            detail="Raw input mode requires preprocessor.pkl, but it is not available."
        )

    raw_dict = raw_features.model_dump()
    assert_no_forbidden_keys(raw_dict, "raw_features")

    missing = [col for col in raw_feature_columns if col not in raw_dict]
    extra = [col for col in raw_dict.keys() if col not in raw_feature_columns]
    if missing:
        raise HTTPException(status_code=400, detail=f"Missing raw feature(s): {missing}")
    if extra:
        raise HTTPException(status_code=400, detail=f"Unexpected raw feature(s): {extra}")

    if raw_dict["hypertension"] not in [0, 1]:
        raise HTTPException(status_code=400, detail="hypertension must be 0 or 1.")
    if raw_dict["heart_disease"] not in [0, 1]:
        raise HTTPException(status_code=400, detail="heart_disease must be 0 or 1.")

    raw_df = pd.DataFrame([{col: raw_dict[col] for col in raw_feature_columns}], columns=raw_feature_columns)

    try:
        transformed = preprocessor.transform(raw_df)
    except Exception as exc:
        raise HTTPException(status_code=400, detail=f"Raw preprocessing failed: {exc}")

    if isinstance(transformed, pd.DataFrame):
        transformed = transformed.copy()
        transformed.columns = transformed.columns.astype(str)
        if set(feature_columns).issubset(set(transformed.columns)):
            transformed = transformed[feature_columns]
        processed_arr = transformed.to_numpy(dtype=np.float32)
    else:
        if hasattr(transformed, "toarray"):
            transformed = transformed.toarray()
        processed_arr = np.asarray(transformed, dtype=np.float32)

    processed_arr = processed_arr.reshape(1, -1)
    if processed_arr.shape[1] != len(feature_columns):
        raise HTTPException(
            status_code=500,
            detail=f"Preprocessor output must have {len(feature_columns)} features, got {processed_arr.shape[1]}."
        )

    if not np.all(np.isfinite(processed_arr)):
        raise HTTPException(status_code=500, detail="Preprocessor output contains non-finite values.")

    return processed_arr


@app.post("/predict")
def predict(payload: PredictionRequest):
    if payload.mode == "processed":
        if payload.features is None:
            raise HTTPException(status_code=400, detail="Processed mode requires 'features'.")
        if payload.raw_features is not None:
            raise HTTPException(status_code=400, detail="Processed mode must not include 'raw_features'.")
        try:
            processed_arr = np.asarray(payload.features, dtype=np.float32)
        except Exception as exc:
            raise HTTPException(status_code=400, detail=f"Features must be numeric: {exc}")
        result = predict_processed_array(processed_arr)
        result["input_mode"] = "processed"
        result["feature_order_source"] = "feature_mapping.json"
        return result

    if payload.mode == "raw":
        if payload.raw_features is None:
            raise HTTPException(status_code=400, detail="Raw mode requires 'raw_features'.")
        if payload.features is not None:
            raise HTTPException(status_code=400, detail="Raw mode must not include 'features'.")
        processed_arr = transform_raw_features(payload.raw_features)
        result = predict_processed_array(processed_arr)
        result["input_mode"] = "raw"
        result["feature_order_source"] = "feature_mapping.json"
        return result

    raise HTTPException(status_code=400, detail="mode must be either 'processed' or 'raw'.")
